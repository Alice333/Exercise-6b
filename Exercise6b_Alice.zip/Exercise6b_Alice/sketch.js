var apple;

function Object(x, y) {
  this.loc = createVector(x, y);
  this.v = createVector(0, 0);
  this.a = createVector(3, 0);
  

  this.Update = function() {
    this.v.add(this.a);
    this.loc.add(this.v);
    this.loc.add(this.v);
  }

  this.body = function() {

    translate(this.loc.x, this.loc.y);
    scale(1.2);
    
 
  line(149,226,240,226);
  line(118,333,209,333);
  line(149,226,118,333);
  line(240,226,209,333);
  
  fill(20,255,0);
  line(139,263,109,278);
  line(230,266,249,277);
 
 
  }
  this.head = function(){
  translate(this.loc.x, this.loc.y);
  scale(0.5);
  
  fill(255,0,0);
  ellipse(200,160,130,130);
  fill(30,30,30);
  rect(195,48,16,46);
  fill(90,100,30);
  triangle(168,137,156,151,180,151);
  triangle(217, 138,209,151, 225,151);
  fill(30,135,200);
  arc(190,184,30,30,0, PI+QUARTER_PI, CHORD);
  
  }
  
  this.feet = function(){
    translate(this.loc.x, this.loc.y);
    scale(1.2);
    
    fill(0,255,0);
    ellipse(140,335,30,40);
    ellipse(183,335,30,40);
  }
  
  this.bounceback = function() {


    if (this.loc.x > width) {
      this.loc.x = 0;
    } 
    
    else if (this.loc.x < 0) {
      this.loc.x = width;
    }

    if (this.loc.y > height) {
      this.loc.y = 0;
    } 
    
    else if (this.loc.y < 0) {
      
      this.loc.y = height;
    }
  }
}

function setup() {
  createCanvas(600, 600);
  apple = new Object(0, 0);
  
}


function draw() {
  background(255);
  apple.body();
  apple.head();
  apple.Update();
  apple.feet();
  apple.bounceback();
}

